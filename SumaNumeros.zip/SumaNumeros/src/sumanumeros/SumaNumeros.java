
public class SumaNumeros {

    public static void main(String[] args) {

        int sumaPares = 0;
        int sumaImpares = 0;
        int contadorPares = 0;
        int contadorImpares = 0;

        // Suma de los 3 primeros números pares
        for (int i = 1; contadorPares < 3; i++) {
            if (i % 2 == 0) {
                sumaPares += i;
                contadorPares++;
            }
        }

        // Suma de los 3 primeros números impares
        for (int i = 1; contadorImpares < 3; i++) {
            if (i % 2 != 0) {
                sumaImpares += i;
                contadorImpares++;
            }
        }

        System.out.println("La suma de los 3 primeros números pares es: " + sumaPares);
        System.out.println("La suma de los 3 primeros números impares es: " + sumaImpares);
    }
}
