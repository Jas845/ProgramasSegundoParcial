package listafamilia;

import java.util.ArrayList;
import java.util.List;

public class ListaFamilia {
    private List<String> nombres;

    public ListaFamilia() {
        nombres = new ArrayList<String>();
    }

    public void agregarNombre(String nombre) {
        nombres.add(nombre);
    }

    public void imprimirNombres() {
        for (int i = 0; i < nombres.size(); i++) {
            System.out.println(nombres.get(i));
        }
    }

    public static void main(String[] args) {
        ListaFamilia listaFamilia = new ListaFamilia();
        listaFamilia.agregarNombre("Jasiel Esau Rojas Cortes");
        listaFamilia.agregarNombre("Nora Maria Cortes Moreno");
        listaFamilia.agregarNombre("Samantha Abigail Rojas Cortes");
        listaFamilia.agregarNombre("Ramon Rojas Ramirez");
        listaFamilia.imprimirNombres();
    }
}
