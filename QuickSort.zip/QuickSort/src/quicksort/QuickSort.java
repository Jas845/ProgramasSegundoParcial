
public class QuickSort {

    public static void quickSort(int[] arr) {
        if (arr == null || arr.length == 0) {
            return;
        }
        quickSort(arr, 0, arr.length - 1);
    }

    private static void quickSort(int[] arr, int inicio, int fin) {
        int i = inicio;
        int j = fin;
        int pivote = arr[inicio + (fin - inicio) / 2];

        while (i <= j) {
            while (arr[i] < pivote) {
                i++;
            }
            while (arr[j] > pivote) {
                j--;
            }
            if (i <= j) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
                j--;
            }
        }

        if (inicio < j) {
            quickSort(arr, inicio, j);
        }
        if (i < fin) {
            quickSort(arr, i, fin);
        }
    }
}
