package com.mycompany.ackermann;

import java.util.Scanner;

public class Ackermann {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca el valor de m: ");
        int m = sc.nextInt();
        System.out.print("Introduzca el valor de n: ");
        int n = sc.nextInt();
        int resultado = ackermann(m, n);
        System.out.println("El resultado de la función de Ackermann para m = " + m + " y n = " + n + " es: " + resultado);
    }
    
    public static int ackermann(int m, int n) {
        if (m == 0) {
            return n + 1;
        } else if (m > 0 && n == 0) {
            return ackermann(m - 1, 1);
        } else {
            return ackermann(m - 1, ackermann(m, n - 1));
        }
    }
}

