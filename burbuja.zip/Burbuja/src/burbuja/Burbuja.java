
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Burbuja {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de valores que desea ordenar: ");
        int tamano = scanner.nextInt();
        int[] numeros = numerosaleatorios(tamano);
        System.out.println("Numeros Antes del Ordenamiento: " + Arrays.toString(numeros));
        for (int i = 0; i < numeros.length - 1; i++) {
            int menor = i;
            for (int j = i + 1; j < numeros.length; j++) {
                if (numeros[j] < numeros[menor]) {
                    menor = j;
                }
            }
            int temp = numeros[i];
            numeros[i] = numeros[menor];
            numeros[menor] = temp;
        }
        System.out.println(" Numeros Despues del Ordenamiento: " + Arrays.toString(numeros));
    }

    private static int[] numerosaleatorios(int tamano) {
        int[] numeros = new int[tamano];
        Random random = new Random();
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(100);
        }
        return numeros;
    }
}
