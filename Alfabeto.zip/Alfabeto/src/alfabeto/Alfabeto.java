
public class Alfabeto {

    public static void main(String[] args) {
        for (char c = 'A'; c <= 'Z'; c++) {

            System.out.print(c + "" + Character.toLowerCase(c));

        }
    }
}
