package arreglounidimencional;

public class ArregloUnidimencional {

    public static void main(String[] args) {
        int[] numero = new int[20];

        numero[0] = 2;
        numero[1] = 4;
        numero[2] = 6;
        numero[3] = 8;
        numero[4] = 10;
        numero[5] = 12;
        numero[6] = 14;
        numero[7] = 16;
        numero[8] = 18;
        numero[9] = 20;
        numero[10] = 22;
        numero[11] = 24;
        numero[12] = 26;
        numero[13] = 28;
        numero[14] = 30;
        numero[15] = 32;
        numero[16] = 34;
        numero[17] = 36;
        numero[18] = 38;
        numero[19] = 40;
    }

}
