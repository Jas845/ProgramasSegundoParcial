import java.util.Scanner;

public class TorresHanoi {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el número de discos: ");
        int n = sc.nextInt();
        torresHanoi(n, 'A', 'B', 'C');
    }
    
    public static void torresHanoi(int n, char origen, char auxiliar, char destino) {
        if (n == 1) {
            System.out.println("Mover disco 1 de la torre " + origen + " a la torre " + destino);
        } else {
            torresHanoi(n-1, origen, destino, auxiliar);
            System.out.println("Mover disco " + n + " de la torre " + origen + " a la torre " + destino);
            torresHanoi(n-1, auxiliar, origen, destino);
        }
    }
}

