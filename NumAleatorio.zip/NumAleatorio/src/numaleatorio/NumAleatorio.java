package numaleatorio;

import java.util.Random;

public class NumAleatorio {

    public static void main(String[] args) {
        int[] arreglo = new int[20]; // se crea el arreglo de 15 elementos

        // se llena el arreglo con valores aleatorios
        Random rnd = new Random();
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = rnd.nextInt(100); // se genera un número aleatorio entre 0 y 99
        }

        // se imprime el arreglo 
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i] + " ");
        }
    }

}
